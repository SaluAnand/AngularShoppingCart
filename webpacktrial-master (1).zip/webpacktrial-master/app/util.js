export default class Util{
    add(x,y){
        return x + y;
    }


}