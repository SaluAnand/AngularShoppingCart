var lodash = require('lodash');
var util = require('./util');

var arr1 = [1,2];

var arr2 = [3,4];

var res = lodash.concat(arr1,arr2);

console.log(util.add(2,3));

console.log(res);